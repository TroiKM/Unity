﻿using UnityEngine;
using System.Collections;

public class TouchInput : MonoBehaviour {

	void Update () {
	
	}
}
